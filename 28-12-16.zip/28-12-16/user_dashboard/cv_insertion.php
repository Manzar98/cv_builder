<?php 
/////////////////////Main Resume Form/////////////////////////
include '../commonfile.php';
include 'header.php';
session_start();
// echo $_SESSION['isfilled'];
echo "<hr>";


    # code...
$query='SELECT `cv`.*, `users`.*
FROM `cv`
LEFT JOIN `users` ON `cv`.`user_id` = `users`.`id`
        Where  cv.user_id ='.$_GET['id'].' AND cv.id='.$_GET['cv_id'].'';///header('Location: cv_insertion.php?"(id)"='.$_POST['userid']);








        
        $_SESSION['password'];
        $_SESSION['Email'];

        $sqlQuery = mysql_query($query) or die(mysql_error());

        if(mysql_num_rows($sqlQuery) > 0){
         $result = mysql_fetch_assoc($sqlQuery);
           // print_r($result);

       }

       ?>


       <div class="container">
         <div class="col-md-1"></div>
         <div class="col-md-10">
           <form action="preview.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" id="USERSID" name="user_id" value="<?php echo $_GET['id']?>"><br>
            <input type="hidden" id="CVID" name="cv_id" value="<?php echo $_GET['cv_id'];?>"><br>



            <div class="form-group row">
             <label for="example-search-input" class="col-xs-2 col-form-label">CV-Title</label>
             <div class="col-xs-6">
              <input class="form-control" type="text" name="cv_title" value="<?php echo$result['cv_title']; ?>">
            </div>
          </div>
          <div class="form-group row">
           <label for="example-search-input" class="col-xs-2 col-form-label">Description</label>
           <div class="col-xs-6">
            <textarea class="form-control" type="text" name="description" ><?php echo $result['description']; ?></textarea>
          </div>
        </div>


        <div class="headingBASE text-center">
          <h2>BASIC INFO</h2>
        </div>
        <div class="common-border">
          <div class="form-group  row">
          <label for="exampleTextarea" class="col-xs-2 col-form-label">Mission/Objective</label>
            <div class="col-sm-10">
              <textarea class="form-control" name="anyquot" rows="3" cols="30" ><?php echo$result['anyquot']; ?></textarea>
            </div>
          </div>
          <div class="form-group ">
            <div class="form-inline row">
              <label for="example-text-input" class="col-xs-2 col-form-label">First-Name</label>
              <div class="col-sm-4">
                <input class="form-control" type="text" name="first_name" value="<?php echo $result['first_name']?>">
              </div>
              <label for="example-search-input" class="col-xs-2 col-form-label">Last-Name</label>
              <div class="col-sm-4">
                <input class="form-control" type="text"  name="last_name" value="<?php echo $result['last_name']; ?>">
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-inline row">
              <label for="example-tel-input" class="col-xs-2 col-form-label">Telephone</label>
              <div class="col-sm-4">
                <input class="form-control" type="text" name="cell_no" value="<?php echo $result['cell_no']; ?>">
              </div>  
              <label for="example-tel-input" class="col-xs-2 col-form-label">Address</label>
              <div class="col-sm-4">
                <input class="form-control" type="text" name="address"  value="<?php echo$result['address']; ?>">
              </div>
            </div>
          </div>
          <div class="form-group  row">
            <label for="exampleTextarea" class="col-xs-2 col-form-label">About</label>
            <div class="col-sm-10">
              <textarea class="form-control" name="moredetail" rows="3" cols="30" ><?php echo $result['moredetail']; ?></textarea>
            </div>
          </div>
        </div>

        <!--        EDUCATION     --> 
        <div class="headingEDU text-center">
         <h2>EDUCATION INFO</h2>
       </div>
       <div class="common-border">
         <button onclick="addEducation()" type="button" class="btn btn-primary pull-right righBtns">Add Education</button>
         <div id="EDUCATION">
          <?php 
          $eduQuery='SELECT * FROM education Where education.user_id='.$_GET['id'].' AND education.cv_id='.$_GET['cv_id'].'' ;     
          $edusqlQuery= mysql_query($eduQuery) or die(mysql_error());           

          if (mysql_num_rows($edusqlQuery)>0) {


            // while ($edu=mysql_fetch_assoc($edusqlQuery)) { ?>
            <input type="hidden" name="edu_Id[]" value="<?php echo $edu['id'] ?>">

            <div class="form-group commonBTNs">
              <div class="form-inline row">
                <label for="example-search-input" class="col-xs-2 col-form-label">Education-Title</label>
                <div class="col-sm-4">
                  <input class="form-control" type="text" name="edu_title[]" value="<?php echo $edu['edu_title'] ?>">
                </div>
                <label for="example-search-input" class="col-xs-2 col-form-label">Education-Name</label>
                <div class="col-sm-4">
                  <input class="form-control" type="text" name="edu_name[]"  value="<?php echo $edu['edu_name']?>">
                </div>
              </div>
            </div>

            <div class="form-group">
              <div class="form-inline row">
                <label for="example-search-input" class="col-xs-2 col-form-label">Year Of Passing</label>
                <div class="col-sm-4">
                 <input class="form-control" type="text" name="edu_passingyear[]" value="<?php echo $edu['edu_passingyear'] ?>">
               </div>



               <label for="example-search-input" class="col-xs-2 col-form-label">Percentage</label>
               <div class="col-sm-4">
                 <input class="form-control" type="text" name="percentage[]" value="<?php echo $edu['percentage'] ?>">
               </div>
             </div>
           </div>
           <br><hr>
           <?php  /* }*/
         }else{?>

         <input type="hidden" name="edu_Id[]" value="0">

         <div class="form-group">
           <div class="form-inline row">
            <label for="example-search-input" class="col-xs-2 col-form-label">Education-Title</label>
            <div class="col-sm-4">
              <input class="form-control" type="text" name="edu_title[]">
            </div>
            <label for="example-search-input" class="col-xs-2 col-form-label">Education-Name</label>
            <div class="col-sm-4">
              <input class="form-control" type="text" name="edu_name[]">
            </div>
          </div>
        </div>


        <div class="form-group ">
         <div class="form-inline row">
           <label for="example-search-input" class="col-xs-2 col-form-label">Year Of Passing</label>
           <div class="col-sm-4">
            <input class="form-control" type="text" name="edu_passingyear[]"><br>
          </div>
          <label for="example-search-input" class="col-xs-2 col-form-label">Percentage</label>
          <div class="col-sm-4">
            <input class="form-control" type="text" name="percentage[]"><br>
          </div>
        </div>
      </div>
       <br><hr>
      <?php } ?>

    </div>
    <script type="text/javascript">

      function addEducation() {
    // body...

    event.preventDefault();
    var eduWrap=document.getElementById('EDUCATION');
    var edu_ID='<input type="hidden" name="edu_Id[]" value="0">';

    var edutitle='<div class="form-group"><div class="form-inline row"><label for="example-search-input" class="col-xs-2 col-form-label">Education-Title</label><div class="col-sm-4"><input class="form-control" type="text" name="edu_title[]"></div>';

    var eduname='<label for="example-search-input" class="col-xs-2 col-form-label">Education-Name</label><div class="col-sm-4"><input class="form-control" type="text" name="edu_name[]"></div></div></div>';

    var edupassing=' <div class="form-group"><div class="form-inline row"><label for="example-search-input" class="col-xs-2 col-form-label">Year Of Passing</label><div class="col-sm-4"><input class="form-control" type="text" name="edu_passingyear[]"></div>';

    var percent='<label for="example-search-input" class="col-xs-2 col-form-label">Percentage</label><div class="col-sm-4"><input class="form-control" type="text" name="percentage[]"></div></div></div></br><hr>';
    eduWrap.innerHTML += edutitle+eduname+edu_ID+edupassing+percent;

  };
</script>
</div>
<!--    EDUCATION-END    -->


<!--    EXPERIENCE    -->
<div class="headingEXP text-center">
 <h2>EXPERIENCE INFO</h2>
</div>
<div class="common-border">
  <div id="addinput">

    <button onclick="addExperience(event)" type="button" class="btn btn-primary pull-right righBtns">Add Experience</button>
    <?php 
    $expQuery='SELECT * FROM experience Where experience.user_id='.$_GET['id'].' AND experience.cv_id='.$_GET['cv_id'].'';
    $expsqlQuery=mysql_query($expQuery)or die(mysql_error());
    if ( mysql_num_rows($expsqlQuery)>0) {
     # code...

      while ($exp = mysql_fetch_assoc($expsqlQuery)) {
   // if (!empty($exp['companyname'])) {

    //echo $result['companyname'].'  : '.$exp['companyname']."<br/>";
        ?>
        <input type="hidden" name="exp_Id[]" value="<?php echo $exp['id'] ?>" >

        <div class="form-group commonBTNs">
          <div class="form-inline row">
           <label for="example-search-input" class="col-xs-2 col-form-label">Company</label>
           <div class="col-sm-4">
            <input class="form-control" type="text" name="companyname[]" value="<?php echo $exp['companyname']; ?>">
          </div>
          <label for="example-search-input" class="col-xs-2 col-form-label">position </label>
          <div class="col-sm-4">
            <input  class="form-control" type="text" name="position[]" value="<?php echo $exp['position']; ?>">
          </div>
        </div>
      </div>


      <div class="form-group ">
        <div class="form-inline row">
         <label for="example-search-input" class="col-xs-2 col-form-label">Post-Detail</label>
         <div class="col-sm-4">
          <input  class="form-control" type="text" name="post_detail[]" value="<?php echo $exp['post_detail']; ?>">
        </div>
        <label for="example-search-input" class="col-xs-2 col-form-label">Time-Period</label>
        <div class="col-sm-4">
          <input  class="form-control" type="text" name="timeperiod[]" value="<?php echo $exp['timeperiod']; ?>"><br/>
        </div>
      </div>
    </div>
   <br><hr>
    <?php
  } 

}else{ ?>


<input type="hidden" name="exp_Id[]" value="0">

<div class="form-group">
  <div class="form-inline row">
   <label for="example-search-input" class="col-xs-2 col-form-label">Company</label>
   <div class="col-sm-4">
     <input class="form-control" type="text" name="companyname[]" value="">
   </div>
   <label for="example-search-input" class="col-xs-2 col-form-label">Position</label>
   <div class="col-sm-4">
     <input class="form-control" type="text" name="position[]" value="">
   </div>
 </div>
</div>


<div class="form-group">
  <div class="form-inline row">
   <label for="example-search-input" class="col-xs-2 col-form-label">Post-Detail</label>
   <div class="col-sm-4">
    <input class="form-control" type="text" name="post_detail[]" value="">
  </div>
  <label for="example-search-input" class="col-xs-2 col-form-label">Time-Period</label>
  <div class="col-sm-4">
    <input class="form-control" type="text" name="timeperiod[]" value=""><br/>
  </div>
</div>
</div>
<br><hr>
<?php
}
?>
</div>

<script type="text/javascript">
  function addExperience(event)
  {
    event.preventDefault();
    var expwrap = document.getElementById('addinput');
    //console.log(expwrap);
    var exp_ID='<input type="hidden" name="exp_Id[]" value="0">';

    var companyname='<div class="form-group"><div class="form-inline row"><label for="example-search-input" class="col-xs-2 col-form-label">Company</label><div class="col-sm-4"><input class="form-control" type="text" name="companyname[]" ></div>';

    var position='<label for="example-search-input" class="col-xs-2 col-form-label">Position</label><div class="col-sm-4"><input class="form-control" type="text" name="position[]" ></div></div></div>';

    var post_detail='<div class="form-group"><div class="form-inline row"><label for="example-search-input" class="col-xs-2 col-form-label">Post-Detail</label><div class="col-sm-4"><input class="form-control" type="text" name="post_detail[]" ></div>';

    var timeperiod='<label for="example-search-input" class="col-xs-2 col-form-label">Time-Period</label><div class="col-sm-4"><input class="form-control" type="text" name="timeperiod[]" ></div></div></div><br/><hr>';

    expwrap.innerHTML += companyname+position+exp_ID+post_detail+timeperiod;

  };

</script>
</div>
<!--   EXPERIENCE-END      -->


<div class="headingSKILL text-center">
  <h2>SKILLS</h2>
</div>
<div class="common-border">
  <div class="form-group  row">
    <label for="exampleTextarea" class="col-xs-2 col-form-label">TechnicalSkill</label>
    <div class="col-xs-10">
      <textarea class="form-control" name="techskill" rows="5" cols="40" ><?php echo$result['techskill']; ?></textarea>
    </div>
  </div>
  <div class="form-group  row">
    <label for="exampleTextarea" class="col-xs-2 col-form-label">Non-TechnicalSkill</label>
    <div class="col-xs-10">
      <textarea class="form-control" name="progskill" rows="5" cols="40" ><?php echo$result['progskill']; ?></textarea>
    </div>
  </div>
</div>



<!--    PORTFOLIO       -->

<div class="headingPORT text-center">
 <h2>PORTFOLIO</h2>
</div>
<div class="common-border">
  <div id="PORT-FOLIO">

    <button onclick="PORTFOLIO(event)" type="button" class="btn btn-primary pull-right righBtns">Add Portfolio</button></br>
    <?php

    $portQuery='SELECT * FROM porfolio Where porfolio.user_id='.$_GET['id'].' AND porfolio.cv_id='.$_GET['cv_id'].'';

    $portsqlQuery=mysql_query($portQuery) or die(mysql_error());

    if (mysql_num_rows($portsqlQuery)>0) {
     # code...

     while ( $ports=mysql_fetch_assoc($portsqlQuery)) {  ?>
     <div id="removeElement_<?php echo $ports['id']; ?>">
       <!-- <input type="text" name="" value="<?php echo $ports['id'];?>"> -->
       <input type="hidden"  name="port_Id[]" value="<?php echo $ports['id'];?>">

       <div class="form-group commonBTNs">
         <div class="form-inline row">
          <label for="example-search-input" class="col-xs-2 col-form-label">Portfolio-Title</label>
          <div class="col-sm-4">
           <input class="form-control" disabled="disabled" type="text" name="port_title[]" value=" <?php echo $ports['port_title'];?>">
         </div>
         <label for="example-search-input" class="col-xs-2 col-form-label">Portfolio-Image</label>
         <div class="col-sm-4">
          <!--portfolio-IMG:<input type="file" name="port_img[]" value="<?php   //echo?>">-->
          <img src="<?php echo $ports['port_img'] ?>" width="100px" height="100px">
          <button id="hideimg_<?php echo $ports['id']; ?>" class="btn btn-info btn-xs" onclick=" deleteMe(event)" type="button">X</button>
        </div>
      </div>
    </div>

  </div>
  <?php 
}?> 
<?php  
}else{
 ?>
 <div class="form-group">
   <div class="form-inline row">
     <label for="example-search-input" class="col-xs-2 col-form-label">Portfolio-Title</label>
     <div class="col-sm-4">
      <input type="hidden" name="port_Id[]" value="0">
      <input class="form-control" type="text" name="port_title[]">
    </div>
    <label for="example-search-input" class="col-xs-2 col-form-label">Portfolio-Image</label>
    <div class="col-sm-4">
      <input  type="file" name="port_img[]">
    </div>
  </div>
</div>


<?php
} ?>
</div>
<script type="text/javascript">

  function deleteMe(event) {

    var portfolioId=event.currentTarget.id;
    console.log(portfolioId);
    var splitId=portfolioId.split("_");
    console.log(splitId);
    var parseId= parseInt(splitId[1]);
    console.log(parseId);
    var USERSID=document.getElementById('USERSID').value;
    console.log(USERSID);
    var CVID=document.getElementById('CVID').value;
    console.log(CVID);
    var xhttp= new XMLHttpRequest();
    xhttp.onreadystatechange = function(){
      if (this.readyState == 4 && this.status == 200){
        var jsonID=JSON.parse(this.responseText);
        console.log(jsonID);
        document.getElementById('removeElement_'+parseId).remove();

      }
    }

    xhttp.open("GET" ,"deleteportfolio.php?id="+parseId+"&userid="+USERSID+"&cv_id="+CVID , true);
    xhttp.send();
  }

  function  PORTFOLIO(event) {
    // body...
    event.preventDefault();
    var port_ID='<input type="hidden" name="port_Id[]" value="0">';
    var portfoliowarp=document.getElementById('PORT-FOLIO');
    var port_title='<div class="form-group"><div class="form-inline row"><label for="example-search-input" class="col-xs-2 col-form-label">Portfolio-Title</label><div class="col-sm-4"><input class="form-control" type="text" name="port_title[]"></div>';
    var port_img='<label for="example-search-input" class="col-xs-2 col-form-label">Portfolio-Image</label><div class="col-sm-4"> <input  type="file" name="port_img[]"></div></div></div>';
    portfoliowarp.innerHTML+=port_title+port_ID+port_img;
  }
</script>
</div>




            <div class="headingEXTRA text-center">
              <h2>EXTRACURRICULAR</h2>
              </div>
            <div class="common-border">
            <div class="form-group row">
             <label for="example-search-input" class="col-xs-2 col-form-label">Extras</label>
             <div class="col-xs-6">
              <input class="form-control" type="text" name="extras" value="<?php echo$result['extras']; ?>">
            </div>
            </div>
            </div><br>
<input type="submit" value="submit" class="btn btn-success pull-left">


</form>
</div>
</div>

</body>
</html>
<?php  
include '../footer.php';






?>