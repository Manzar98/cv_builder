<?php
include '../commonfile.php';
session_start();
if(isset($_SESSION['Email'])){
$myid=$_GET['id'];


   






$slctquery= 'DELETE `cv`.*, `education`.*, `experience`.*, `porfolio`.*
FROM `cv`
    LEFT JOIN `education` ON `education`.`cv_id` = `cv`.`id`
    LEFT JOIN `experience` ON `experience`.`cv_id` = `cv`.`id`
    LEFT JOIN `porfolio` ON `porfolio`.`cv_id` = `cv`.`id` WHERE 
  `cv`.`id` ='.$_GET['cv_id'].' ';

$slctsql=mysql_query($slctquery) or die(mysql_error());


header('Location: cvmenue.php?id='. $myid);

}
else {
	echo ' Your not an authorized';
	
	}


?>