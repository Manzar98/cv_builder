<?php  
///////////////////Lists Of CV Page///////////////////////

include '../commonfile.php';
include 'header.php';



$query = '  SELECT * FROM cv WHERE user_id='.$_GET['id'];
$result = mysql_query($query)or die(mysql_error());
$userid='';
//print_r($result);


if(mysql_num_rows($result) >0){
	//echo 'Successfuly authorized';
  ?>	
  <div class="container">
    <h2 class="text-center">Lists of Resume Create</h2><br>
    <div class="row">

      <?php
while ($crntresult=mysql_fetch_assoc($result)) {//for exract out id we use this  
	# code...
	//print_r($crntresult);

   // $pathInPieces = explode(DIRECTORY_SEPARATOR , __FILE__);
   // echo $pathInPieces[3].DIRECTORY_SEPARATOR.$pathInPieces[4].DIRECTORY_SEPARATOR.$pathInPieces[5].DIRECTORY_SEPARATOR;
     
  ?>

  <div class="col-sm-4 col-md-3 clear-fix">
    <div class="card">
      <div class="card-block">
        <h3 class="card-title"><?php echo $crntresult['cv_title'];  ?></h3>
        <p class="card-text" ><?php echo $crntresult['description'];  ?></p>
        <button class="btn btn-default btn-transparent BTN"><a href="cv_insertion.php?id=<?php echo $crntresult['user_id']; ?>&cv_id=<?php echo $crntresult['id'];  ?>" data-toggle="tooltip" data-placement="bottom" title="Edit Resume"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></button>
        <button class="btn btn-default btn-transparent BTN"><a href="resume_delete.php?id=<?php echo $crntresult['user_id']; ?>&cv_id=<?php echo $crntresult['id'];  ?>" data-toggle="tooltip" data-placement="bottom" title="Delete Resume"><i class="fa fa-trash-o" aria-hidden="true"></i></a></button>
        <button class="btn btn-default btn-transparent button BTN"><a href="/learning/Php/28-12-16/templates /links.php?id=<?php echo $crntresult['user_id']; ?>&cv_id=<?php echo $crntresult['id'];  ?>" data-toggle="tooltip" data-placement="bottom" title="Preveiw Resume"><i class="fa fa-eye" aria-hidden="true"></i></a></button>
       
   </div>
 </div>
</div>


<?php
$userid=$crntresult['user_id'];


}//end while ?>
</div>
</div>
<?php  }//end if 


?>

<a href="newmenue.php?id=<?php echo $userid; ?>" class="border-circle " data-toggle="tooltip" data-placement="top" title="Create New Resume"><i class="fa fa-pencil btn-success" aria-hidden="true"></i></a>

 











