<?php



		/*while ( $crntresult=mysql_fetch_assoc($slctsql) ) {
			$file = $_FILES['port_img']['name'];
			$tmpPath = $_FILES['port_img']['tmp_name'];
			$targetDir = '../uploadPicture/';
print_r($file);
		}
		if(move_uploaded_file($tmpPath, $targetDir.$file)){
	//echo 'File upload on path  : '.$targetDir.$file;
			$uploadportfolio = $targetDir.$file;
		}else{
			echo 'Some thing wrong with the uploading';
		}*/
/////////////////////////////PortFolio///////////////////////////////////
 
 // echo count($_POST['port_title'])."</br>";
for ($i=0; $i<count($_POST['port_title']); $i++) { 


$targetDir = '../uploadPicture/';

		$slctquery= 'SELECT * from porfolio WHERE user_id='.$id.' AND cv_id='.$cv_id.' AND id='.$_POST['port_Id'][$i];

		echo $slctquery."</br>";

		$slctsql=mysql_query($slctquery) or die(mysql_error());

//echo mysql_num_rows($slctsql);
		/*if (mysql_num_rows($slctsql)> 0) {
			
			
	//$queryresult=mysql_fetch_assoc($slctsql);
				if (isset($_FILES["port_img"]["name"][$i])) {
					
					$file_name=$_FILES["port_img"]["name"][$i];
				echo $file_name;
				
				$updatedfolio='UPDATE porfolio SET 
				port_title="'.$_POST['port_title'][$i].'",
				port_img="'.$targetDir.$file_name.'" WHERE user_id='.$id.' AND cv_id='.$cv_id. ' AND id='.$_POST['port_Id'][$i]; 
				echo $updatedfolio."</br>";
				$updatedresult=mysql_query($updatedfolio)or die(mysql_error());
				
				uploadingFILE($file_name,$_FILES['port_img']['tmp_name'][$i]);
				}
				
		}*/
			if (isset($_FILES["port_img"]["name"][$i])) {
					

					$file_name=$_FILES["port_img"]["name"][$i];
				$instquery='INSERT INTO porfolio(user_id,cv_id,port_title,port_img)VALUES
				("'.$id.'","'.$cv_id.'","'.$_POST['port_title'][$i].'","'.$targetDir.$file_name.'")';

                 echo $instquery."</br>";
				$result = mysql_query($instquery)or die(mysql_error());

				 uploadingFILE($file_name,$_FILES['port_img']['tmp_name'][$i]);
				}
		
	}

function  uploadingFILE($file_name,$tmpPath){
            
	    
	$file = $file_name;
			
			echo "<br/>".$tmpPath."<hr/>";
			$targetDir = '../uploadPicture/';

			print_r($file);

		///}
		if(move_uploaded_file($tmpPath, $targetDir.$file)){
	//echo 'File upload on path  : '.$targetDir.$file;
			$uploadportfolio = $targetDir.$file;
		}else{
			echo 'Some thing wrong with the uploading';
		}
// SELECT portfolio where user_id= AND cv_id=,*/

}


?>