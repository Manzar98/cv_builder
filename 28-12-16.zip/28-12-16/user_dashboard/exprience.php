<?php


// echo "<hr>";
// print_r($_POST['company']);
// print_r($_POST['position']);

// for ($i=0; $i < count($_POST['company']) ; $i++) { 
	// echo $_POST['company'][$i]."<br/>";
	// echo $_POST['position'][$i]."<hr>";
// }
// return false;
/////////////////////////////EXPERINCES/////////////////////////////////////
// echo count($_POST['companyname'])."</br>";

for ($i=0; $i<count($_POST['companyname']); $i++){

$slctquery= 'SELECT * from experience WHERE user_id='.$id.' AND cv_id='.$cv_id. '  AND id='.$_POST['exp_Id'][$i] ;
// echo $slctquery."</br>";

$slctsql=mysql_query($slctquery) or die(mysql_error());
//echo mysql_num_rows($slctsql);

if (mysql_num_rows($slctsql)> 0 && !empty($_POST['companyname'][$i]) ) {
	
	
		$updatedexperience='UPDATE experience SET 

		companyname="'.$_POST['companyname'][$i].'",
		position ="'.$_POST['position'][$i].'",
		post_detail="'.$_POST['post_detail'][$i].'",
		timeperiod="'.$_POST['timeperiod'][$i].'" WHERE user_id='.$id.' AND cv_id='.$cv_id . ' AND id='.$_POST['exp_Id'][$i];
        
        // echo "</hr>".$updatedexperience."<br>";
	$updatedresult=mysql_query($updatedexperience)or die(mysql_error());
		
		}
		else if(!empty($_POST['companyname'][$i]))
		{
			$expquery='INSERT INTO experience(user_id,cv_id,post_detail,companyname,position,timeperiod)VALUES
				("'.$id.'","'.$cv_id.'","'.$_POST['post_detail'][$i].'","'.$_POST['companyname'][$i].'","'.$_POST['position'][$i].'","'.$_POST['timeperiod'][$i].'")';
				// echo $expquery."<br>"."</hr>";

				$expresult = mysql_query($expquery)or die(mysql_error());
		}

		}



?>