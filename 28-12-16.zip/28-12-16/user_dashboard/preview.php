

<?php

//////////////////////Update Resume/////////////////////////////////////


include '../commonfile.php';


session_start();
include 'header.php';

$_SESSION['password'];
$_SESSION['Email'];
$_SESSION['isfilled']=true;
$id = $_POST['user_id'];
echo $id;
$cv_id = $_POST['cv_id'];
echo $cv_id;

header("Location: ../templates/links.php?id=".$id."&cv_id=".$cv_id);


$first_name = $_POST['first_name'];
		//echo $first_name."<br>";
$last_name = $_POST['last_name'];
		//echo $last_name."<br>";
// $email = $_POST['email'];
// 		//echo $email."<br>";
// $password = $_POST['password'];
// 		//echo $password."<br>";

$slctquery = 'UPDATE users SET 
first_name="'.$first_name.'",
last_name="'.$last_name.'" WHERE id='.$id;
$result=mysql_query($slctquery)or die(mysql_error());
//print_r($result);




$id=$_POST['user_id'];
echo $id."<br>";
$cell_no = $_POST['cell_no'];
echo $cell_no."<br>";
$address = $_POST['address'];
echo $address."<br>";
$extra = $_POST['extras'];
echo $extra."<br>";
$des=$_POST['description'];
echo $des."<br>";
$shortdetail=$_POST['moredetail'];
echo $shortdetail."<br>";
$quots=$_POST['anyquot'];
echo $quots."<br>";
$tech=$_POST['techskill'];
echo $tech."<br>";
$prog=$_POST['progskill'];
echo $prog."<br>";
$porttitle=$_POST['port_title'];
				//echo $porttitle;





$slctquery = 'UPDATE cv SET 

cell_no="'.$cell_no.'" ,
address="'.$address.'" ,
description="'.$des.'",
moredetail="'.$shortdetail.'",
anyquot="'.$quots.'",
techskill="'.$tech.'",
progskill="'.$prog.'",
extras="'.$extra.'" WHERE user_id='.$id.' AND id='.$cv_id;

$result=mysql_query($slctquery)or die(mysql_error());
 

 include 'education.php';



//Experience Including

//////////////

include 'exprience.php';

/////////////////

//portfolio Including

/////////////////

include 'portfolio.php';






include '../footer.php';
?>

