
<?php

//////////////////////Update Resume/////////////////////////////////////


include '../commonfile.php';


session_start();
include 'header.php';
$_SESSION['password'];
$_SESSION['Email'];
$_SESSION['isfilled']=true;
$id = $_POST['user_id'];
echo $id;
$cv_id = $_POST['cv_id'];
echo $cv_id;

$email = $_POST['email'];
		//echo $email."<br>";
$password = $_POST['password'];
		//echo $password."<br>";

$slctquery = 'UPDATE users SET 

email="'.$email.'",
password="'.$password.'" WHERE id='.$id;
$result=mysql_query($slctquery)or die(mysql_error());



/////////////////////////

//  Upload profilePIC

/////////////////////////
if (isset($_POST['profile_img']) && !empty($_POST['profile_img'])) {
	$upload=$_POST['profile_img'];
}else{
	$file = $_FILES['uploadfile']['name'];
	$tmpPath = $_FILES['uploadfile']['tmp_name'];
	$targetDir = '../uploadPicture/';
	//print_r($file);

	if(move_uploaded_file($tmpPath, $targetDir.$file)){
		//echo 'File upload on path  : '.$targetDir.$file;
		$upload = $targetDir.$file;
	}else{
		echo 'Some thing wrong with the uploading';
	}
}

///////////////



$slctquery = 'UPDATE cv SET 
 uploadfile="'.$upload.'"
 WHERE user_id='.$id.' AND id='.$cv_id;

$result=mysql_query($slctquery)or die(mysql_error());




if ($result == 1){
	echo "Successfully added";
	header("Location: cv_insertion.php?id=".$id."&cv_id=".$cv_id);
}
include '../footer.php';
?>

