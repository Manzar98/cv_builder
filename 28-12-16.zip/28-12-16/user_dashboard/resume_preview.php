
<?php 
/////////////////////Preview Page/////////////////////////
include '../commonfile.php';


session_start();
include 'header.php';
?>




<?php
if(isset($_SESSION['Email'])){


    // echo "<a href='../logout.php'><button>Logout</button> </a>".'<br/>';
    $query='SELECT `cv`.*, `users`.*
    FROM `cv`
    LEFT JOIN `users` ON `cv`.`user_id` = `users`.`id`
    Where  cv.user_id ='.$_GET['id'].' AND cv.id='.$_GET['cv_id'].'';

    $sqlQuery = mysql_query($query) or die(mysql_error());
    echo mysql_num_rows($sqlQuery);
    if(mysql_num_rows($sqlQuery) > 0){
        $result = mysql_fetch_assoc($sqlQuery);
        print_r($result);
    }?>
    <?php?>
    <
    <!DOCTYPE html>
    <html>
    <head>
        <title></title>
    </head>
    <body>

        <div id="#top"></div>
        <section id="home">
            <div class="banner-container">
             <?php echo "<img src=".$result['uploadfile']." />"?>
                <div class="container banner-content">
                    <div id="da-slider" class="da-slider">
                        <div class="da-slide">
                            <h2><?php echo $result['cv_title']; ?></h2>
                            <p><?php echo $result['description']; ?></p>
                            <div class="da-img"></div>
                        </div>

                <!--  <nav class="da-arrows">
                        <span class="da-arrows-prev"></span>
                        <span class="da-arrows-next"></span>
                    </nav> -->
                </div>
            </div>
        </div>
    </section>

    <!--About-->
    <section id="aboutUs" class="secPad">
        <div class="container">
            <div class="heading text-center">
                <!-- Heading -->
                <h2><?php echo  $result['first_name']. $result['last_name'];  ?></h2><br>
                <p><?php echo $result['moredetail'];  ?></p>
            </div>

        </div>
    </div>
</section>

<!--Quote-->
<section id="quote" class="bg-parlex">
    <div class="parlex-back">
        <div class="container secPad text-center">
            <h2><?php echo $result['anyquot'] ;?></h2>
        </div>
        <!--/.container-->
    </div>
</section>

<!--Experience-->
<section id="experience" class="secPad">
    <div class="container">     
        <div class="heading text-center">
            <!-- Heading -->
            <h2>Professional Experience</h2>
        </div>
        <div id="timeline"><div class="row timeline-movement timeline-movement-top">
            <div class="timeline-badge timeline-future-movement">
                <a href="#">
                    <span class="glyphicon glyphicon-plus"></span>
                </a>
            </div>
            <div class="timeline-badge timeline-filter-movement">
                <a href="#">
                    <span class="glyphicon glyphicon-time"></span>
                </a>
            </div>

        </div>
        <div class="row timeline-movement">

            <?php $expQuery='SELECT * FROM experience Where experience.user_id='.$_GET['id'].' AND experience.cv_id='.$_GET['cv_id'].'';
            $expsqlQuery=mysql_query($expQuery)or die(mysql_error()); ?>

            <?php while ($crntresult=mysql_fetch_assoc($expsqlQuery)) {?>
            <div class="col-sm-6  timeline-item">
                <div class="row">
                    <div class="col-sm-offset-1 col-sm-11">
                        <div class="timeline-panel debits">
                            <ul class="timeline-panel-ul">
                                <li><span class="importo"><?php echo $crntresult['companyname']; ?></span></li>
                                <li><span class="causale"><?php echo $crntresult['position']; ?></span> </li>
                                <li><span class="causale"><?php echo $crntresult['post_detail']; ?></span> </li>
                                <li><p><small class="text-muted"><?php echo $crntresult['timeperiod']; ?></small></p> </li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>

            <?php } 
            ?>
        </div>
    </div>
</div>

</section>


<!--Eduction-->
<section id="education" class="secPad">
    <div class="container">     
        <div class="heading text-center">
            <!-- Heading -->
            <h2 class="eduHEADING">Eduction</h2>
        </div>
        <div id="timeline"><div class="row timeline-movement timeline-movement-top">
            <div class="timeline-badge timeline-future-movement">
                <a href="#">
                    <span class="glyphicon glyphicon-plus"></span>
                </a>
            </div>
            <div class="timeline-badge timeline-filter-movement">
                <a href="#">
                    <span class="glyphicon glyphicon-time"></span>
                </a>
            </div>
            
        </div>
        <div class="row timeline-movement">

            <?php $eduQuery='SELECT * FROM education
            Where education.user_id='.$_GET['id'].' AND education.cv_id='.$_GET['cv_id'].'';
            $edusqlQuery=mysql_query($eduQuery)or die(mysql_error()); ?>
            
            <?php while ($crntResult=mysql_fetch_assoc($edusqlQuery)) {?>
            <div class="col-sm-6  timeline-item">
                <div class="row">
                    <div class="col-sm-offset-1 col-sm-11">
                        <div class="timeline-panel debits">
                            <ul class="timeline-panel-ul">
                                <li><span class="importo"><?php echo $crntResult['edu_title']; ?></span></li>
                                <li><span class="causale"><?php echo $crntResult['edu_name']; ?></span> </li>
                                <li><p><small class="text-muted"><?php echo $crntResult['edu_passingyear']; ?></small></p> </li>
                            </ul>
                        </div>
                        
                    </div>
                </div>
            </div>

            <?php } 
            ?>
        </div>
    </div>
</div>

</section>


<!--Portfolio-->
<section id="portfolio" class="page-section section appear clearfix secPad">
    <div class="container">

        <div class="heading text-center">
            <!-- Heading -->
            <h2>Portfolio</h2>
        </div>


        <div class="row">
            <nav id="filter" class="col-md-12 text-center">
                <ul>
                    <li><a href="#" class="current btn-theme btn-small" data-filter="*">All</a></li>
                    <li><a href="#" class="btn-theme btn-small" data-filter=".webdesign">Web Design</a></li>
                    <li><a href="#" class="btn-theme btn-small" data-filter=".photography">Photography</a></li>
                    <li><a href="#" class="btn-theme btn-small" data-filter=".print">Print</a></li>
                </ul>
            </nav>

            <div class="col-md-12">
                <?php  $portQuery='SELECT * FROM porfolio Where porfolio.user_id='.$_GET['id'].' AND porfolio.cv_id='.$_GET['cv_id'].'';

                $portsqlQuery=mysql_query($portQuery) or die(mysql_error()); ?>

                <?php while ($crntresult=mysql_fetch_assoc($portsqlQuery)) {?>


                <div class="row">
                    <div class="portfolio-items isotopeWrapper clearfix" id="3">

                        <article class="col-sm-4 isotopeItem print">
                            <div class="portfolio-item">
                                <?php echo "<img width='100' height='100' src=".$crntresult['port_img']." </br>";  ?>
                                <div class="portfolio-desc align-center">
                                    <div class="folio-info">
                                        <a href= <?php echo "<img width='100' height='100' src=".$crntresult['port_img'] ;?> class="fancybox">
                                            <h5><?php echo $crntresult['port_title']."</br>";?></h5>
                                            <i class="fa fa-arrows-alt fa-2x"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </article>
                        </div>

                    </div>
                    <?php } ?>

                </div>
            </div>

        </div>
    </section>



    <!--Contact -->
    <section id="contactUs" class="page-section secPad">
        <div class="container">

            <div class="row">
                <div class="heading text-center">
                    <!-- Heading -->
                    <h2>Let's Keep In Touch!</h2>
                    <p>Thank you for visiting out my profile. If you would like to get into contact with me, please fill out the form below.</p>
                </div>
            </div>

            <div class="row mrgn30">

                <form method="post" action="" id="contactfrm" role="form">

                    <div class="col-sm-4">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="Enter name" title="Please enter your name (at least 2 characters)">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" id="email" placeholder="Enter email" title="Please enter a valid email address">
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label for="comments">Comments</label>
                            <textarea name="comment" class="form-control" id="comments" cols="3" rows="5" placeholder="Enter your message…" title="Please enter your message (at least 10 characters)"></textarea>
                        </div>
                        <button name="submit" type="submit" class="btn btn-lg btn-primary" id="submit">Submit</button>
                        <div class="result"></div>
                    </div>
                </form>
                <div class="col-sm-4">
                    <h4>Address:</h4>
                    <address>
                        <?php echo $result['address'];?>
                        <br>
                    </address>
                    <h4>Phone:</h4>
                    <address>
                        <?php  $result['cell_no'] ;?><br>
                    </address>
                </div>
            </div>
        </div>
        <!--/.container-->
    </section>
    <?php
}
else{
    echo "need to be rediect";
}




include '../footer.php';
?>
</body>
</html>