<?php  
//echo  count($_POST['edu_title']);
for ($i=0; $i<count($_POST['edu_title']); $i++) { 
	$slctquery='SELECT * from education WHERE user_id='.$id.' AND cv_id='.$cv_id.' AND id='.$_POST['edu_Id'][$i] ;

 //echo $slctquery."<br/>" ;

	$slctsql=mysql_query($slctquery) or die(mysql_error());

	if (mysql_num_rows($slctsql)> 0) {


		//echo $_POST['edu_title'][$i];
		$updatededucation='UPDATE education SET
		edu_title ="'.$_POST['edu_title'][$i].'",
		edu_name ="'.$_POST['edu_name'][$i].'",
		percentage ="'.$_POST['percentage'][$i].'",
		edu_passingyear ="'.$_POST['edu_passingyear'][$i].'" WHERE user_id='.$id.' AND cv_id='.$cv_id . ' AND id='.$_POST['edu_Id'][$i];
		//echo $updatededucation."<br/>";
		$updatedresult=mysql_query($updatededucation)or die(mysql_error());


	}else{



		$eduquery='INSERT INTO education(user_id , cv_id , edu_title , edu_name , edu_passingyear , percentage) VALUES
		("'.$id.'","'.$cv_id.'","'.$_POST['edu_title'][$i].'","'.$_POST['edu_name'][$i].'","'.$_POST['edu_passingyear'][$i].'","'.$_POST['percentage'][$i].'")';
		//echo "<hr>".$eduquery;
		$eduresult = mysql_query($eduquery) or die(mysql_error());

	}


}


?>