<?php
include '../commonfile.php';
include 'header.php';
include 'footer.php';
//$_GET['id'];
$slctquery= 'SELECT * from cv WHERE user_id='.$_GET['id'];
//echo $slctquery;

$slctsql=mysql_query($slctquery) or die(mysql_error());


if (mysql_num_rows($slctsql)> 0) {
	$queryresult=mysql_fetch_assoc($slctsql);
	# code...
}
?>