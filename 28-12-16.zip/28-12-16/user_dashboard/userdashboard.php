

<?php
include '../commonfile.php';
session_start();

?>
     <link rel="stylesheet" type="text/css" href="css/style.css">


<?php        

if(isset($_SESSION['Email'])){
	


		///////////////////////////////
		////////// Authorized User
		//////////////////////////////
		$query='SELECT * FROM cv WHERE user_id='.$_GET['id'];
		$result=mysql_query($query) or die(mysql_error());

		if (mysql_num_rows($result) > 0) {

			$resumeResult=mysql_fetch_assoc($result) ;
		   //$_SESSION['password'];
		   //     $_SESSION['Email'];
		    
		  //print_r($resumeResult);
			include 'cvmenue.php';




				# code...
		}else{
			
			include 'newmenue.php';

			
		}

}else{
	echo ' Your not an authorized';
	header('Location: ../login.php');
}

include '../footer.php';

?>