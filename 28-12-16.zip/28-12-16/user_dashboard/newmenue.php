


<?php 
/////////////////Creation Of CV Title///////////////////////



session_start();
include 'header.php';

 //include 'header.php';
if(isset($_SESSION['Email'])){

	    ///////////////////////////////
		////////// Authorized User
		//////////////////////////////

	
$myid=$_GET['id'];
?>
<div class="container">
        <div class="row">
			<div class="col-md-6 col-md-offset-3">
				<div class="panel Panel-create">
					<div class="panel-heading">
						<div class="row">
							<div class="col-xs-12 center">
								<h2>Create Resume</h2>
							</div>
							
						</div>
						<hr>
					</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-lg-12">

								<form id="title-form" action="newinsert.php" method="post" role="form" style="display: block;">

								<input type="hidden" name="userid" placeholder="user_id" value="<?php echo $myid; ?>">
									<div class="form-group   cv-panel">
										<input type="text"  name="cvtitle" id="cvtitle" tabindex="1" required="required" class="form-control" placeholder="cv-title" value="">
									</div>
									<div class="form-group des-panel">
									
										<textarea type="text" required="required" name="description" id="description" tabindex="2" class="form-control" placeholder="description"></textarea> 
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-sm-6 col-sm-offset-3">
												<input type="submit" value="Submit" id="submit" tabindex="4" class="form-control btn btn-create" value="Create Resume">
											</div>
										</div>
									</div>
								</form>
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


<?php

}
else{
	echo ' Your not an authorized';
	header('Location: ../login.php');
}
include '../footer.php';
?>






























<!-- <h2>MY Resume</h2> 
<form action="newinsert.php" method="POST">
	<input type="hidden" name="userid" placeholder="user_id" value="<?php echo $myid; ?>"></br></br>
	<input type="text" name="cvtitle" placeholder="cv-title">

	<input type="text" name="description" placeholder="description">
   
   <input type="submit" value="submit">
</form>-->








