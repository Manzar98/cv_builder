<?php

///////////////////////////Insertion for Create CV title nd UserID////////////////////////
session_start();
include 'header.php';

include '../commonfile.php';
$id = $_POST['userid'];

$title=$_POST['cvtitle'];
$des=$_POST['description'];
$_SESSION['isfilled']=false;


$query = 'INSERT INTO cv(user_id,cv_title,description)VALUES("'.$id.'","'.$title.'","'.$des.'")';

$result = mysql_query($query)or die(mysql_error());
//print_r($result);

$lastInsertedID = mysql_insert_id(); // Recent inserted value


header('Location: cv_insertion.php?id='.$_POST['userid'].'&cv_id='.$lastInsertedID.'&isnew=y');//agr hmne url mein id bhj wa ni ho to 
                                    //?id=35&cv_id=112&isnew=y

include 'footer.php';
?>                     