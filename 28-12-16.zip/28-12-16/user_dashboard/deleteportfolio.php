<?php

include '../commonfile.php';

$slctquery='DELETE FROM `porfolio` 
            WHERE `user_id` = '.$_GET['userid'].' AND 
            `cv_id` ='.$_GET['cv_id'].' AND 
            `id` ='.$_GET['id'].' ';

$slctsql=mysql_query($slctquery) or die(mysql_error());

$response['status']=true;
$response['message']='Sucessfully Deleted';
 echo json_encode($response);

?>