<?php 
/////////////////////   PROFILE   /////////////////////////
include '../commonfile.php';
include 'header.php';
session_start();
// echo $_SESSION['isfilled'];
echo "<hr>";



$query='SELECT `cv`.*, `users`.*
FROM `cv`
LEFT JOIN `users` ON `cv`.`user_id` = `users`.`id`
        Where  cv.user_id ='.$_GET['id'].' AND cv.id='.$_GET['cv_id'].'';///header('Location: cv_insertion.php?"(id)"='.$_POST['userid']);




      // print_r($query);



        
        $_SESSION['password'];
        $_SESSION['Email'];

        $sqlQuery = mysql_query($query) or die(mysql_error());

        if(mysql_num_rows($sqlQuery) > 0){
         $result = mysql_fetch_assoc($sqlQuery);
            // print_r($result);

       }

       ?>





       <div class="container">
         <div class="col-md-1"></div>
         <div class="col-md-10 text-center">

           <form action="profileSubmission.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" id="USERSID" name="user_id" value="<?php echo $_GET['id']?>"><br>
            <input type="hidden" id="CVID" name="cv_id" value="<?php echo $_GET['cv_id'];?>"><br>




            <div class="headingBASE text-center">
              <h2>PROFILE INFO</h2>
            </div>
            <div class="common-border">

              <?php if (empty($result['uploadfile'])) { ?>
               <div class="col-sm-2"></div>
              <div class="form-group  row">
                <label for="exampleInputFile" class="col-xs-2 col-form-label">Profile Image</label>
                <div  class="col-xs-6">
                  <input type="file"  name="uploadfile" class="form-control-file" id="exampleInputFile" aria-describedby="fileHelp">
                </div>
              </div>



              <?php }else{ ?>
               <div class="col-sm-2"></div>
              <div class="form-group row">
               <label for="exampleInputFile" class="col-xs-2 col-form-label">Profile Image</label>
               <div  class="col-xs-6">
                 <input type="hidden" id="profile_img" name="profile_img"  value="<?php echo $result['uploadfile'] ?>">
                 <input  id="showfile" type="file"  name="uploadfile" style="display:none;">
                 <img id="profileImg" src="<?php echo $result['uploadfile'] ?> " width="100px" height="100px">
                 <button id="hideup" class="btn btn-info btn-xs" onclick="hideME(event)" type="button">X</button>
               </div>
             </div>
  <!-- <div class="form-group row">
   <label for="exampleInputFile" class="col-xs-2 col-form-label"></label>
   <div  class="col-xs-6">

   </div>
 </div> -->
 <script type="text/javascript">

  function hideME(event) {
                      // body...
                      var div1=document.getElementById('hideup');
                      var div3=document.getElementById('profileImg') ;
                      var div4=document.getElementById('profile_img');
                      div4.value="";
                      div1.style.display="none";
                      div3.style.display="none";
                      
                      var div2=document.getElementById('showfile');
                      div2.style.display='block';

                    }

                  </script>

                  <?php  } ?> 
                  <div class="col-sm-2"></div>
                  <div class="form-group row">
                   <label for="example-search-input" class="col-xs-2 col-form-label">E-mail</label>
                   <div class="col-sm-4">
                    <input class="form-control" type="text" name="email" value="<?php echo $result['email']; ?>">
                  </div>
                </div>
                <div class="col-sm-2"></div>
                <div class="form-group row">
                  <label for="example-password-input" class="col-xs-2 col-form-label">Password</label>
                  <div class="col-sm-4">
                    <input class="form-control" type="password" name="password" value="<?php echo $result['password']; ?>">
                  </div>

                </div>


              </div>

              <input type="submit" value="submit" class="btn btn-success">


            </form>
          </div>
        </div>

      </body>
      </html>
      <?php  
      include '../footer.php';
      ?>


















