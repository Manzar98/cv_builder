<?php
/////////////////////////////////////////////
include 'commonfile.php';

$email = $_POST['Email'];
$password = $_POST['password'];


$query = '  SELECT * FROM users WHERE Email="'.$email.'" AND password="'.$password.'" ';

$result = mysql_query($query)or die(mysql_error());


if(mysql_num_rows($result) == 1){
	//echo 'Successfuly authorized';
$crntresult=mysql_fetch_assoc($result) ;//for exract out id we use this  
	 //echo $crntresult['id'] ;
	 session_start();
        $_SESSION['Email']=$email;
        $_SESSION['password']=$password;
      echo $crntresult['user_type'];
     if ($crntresult['user_type']=='admin') {
     	# code...
     	header('Location: admin/index.php?id='.$crntresult['id']);//to send the id for url
     } else{
     	  header('Location: user_dashboard/userdashboard.php?id='.$crntresult['id']);//to send the id for url
     }
  
        
}else{
	echo 'Email or password is incorrect';
}

 ?>