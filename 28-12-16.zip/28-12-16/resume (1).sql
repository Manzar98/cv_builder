-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2016 at 09:08 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `resume`
--

-- --------------------------------------------------------

--
-- Table structure for table `cv`
--

CREATE TABLE `cv` (
  `id` int(25) NOT NULL,
  `description` varchar(285) NOT NULL,
  `cell_no` varchar(20) NOT NULL,
  `address` varchar(500) NOT NULL,
  `anyquot` varchar(500) NOT NULL,
  `moredetail` varchar(500) NOT NULL,
  `qulification_1` varchar(500) NOT NULL,
  `qulification_2` varchar(500) NOT NULL,
  `qulification_3` varchar(500) NOT NULL,
  `techskill` varchar(500) NOT NULL,
  `progskill` varchar(500) NOT NULL,
  `extras` varchar(1000) NOT NULL,
  `user_id` int(25) NOT NULL,
  `cv_title` varchar(100) NOT NULL,
  `uploadfile` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cv`
--

INSERT INTO `cv` (`id`, `description`, `cell_no`, `address`, `anyquot`, `moredetail`, `qulification_1`, `qulification_2`, `qulification_3`, `techskill`, `progskill`, `extras`, `user_id`, `cv_title`, `uploadfile`) VALUES
(93, 'write less, Do more', '123-7654890', '54-saddar road', ' Strepsirrhines are primarily tree-dwelling, feeding on fruit, leaves, and insects. Many are endangered by habitat destruction, poaching for bushmeat, and live capture for the exotic pet trade. (Full article...)', 'Strepsirrhini is a suborder of primates that includes lemurs from Madagascar, bushbabies and pottos from Africa, and lorises from India and southeast Asia. Also included are the extinct adapiform primates, a diverse and widespread group that thrived during the Eocene in Europe, North America, and Asia, but disappeared from most of the Northern ', 'matric: 69.7%', 'F.sc:73.22%', 'Bacholars:67%', 'What links here\r\nRelated changes\r\nUpload file\r\nSpecial pages\r\nPermanent link\r\nPage information\r\nWikidata item', 'Create a book\r\nDownload as PDF\r\nPrintable version', 'stamp collecting ', 35, 'My New Resume', ''),
(124, 'using adobe', '', 'phase 2 peshawar cantt', 'the 1906 Humorous Phases of Funny Faces by J. Stuart Blackton,[19][20] who, because of that, is considered the father of American animation.', 'The first film that was recorded on standard picture film and included animated sequences was the 1900 Enchanted Drawing,[18] which was followed by the first entirely animated film  ', 'matric: 69.7%', 'F.sc:73.22%', 'Bacholars:67%', 'Ilokano\r\nBahasa Indonesia\r\nÐ˜Ñ€Ð¾Ð½\r\nÃslenska\r\nItaliano\r\n×¢×‘×¨×™×ª', 'Deutsch\r\nEesti\r\nÎ•Î»Î»Î·Î½Î¹ÎºÎ¬\r\nEspaÃ±ol\r\nEsperanto', 'stamp collecting ', 35, 'ux/ui developer', ''),
(125, 'Ux/UI Developer', '', '', '', '', '', '', '', '', '', '', 35, 'For JOB', ''),
(126, 'Ux/UI Developer', '', '', '', '', '', '', '', '', '', '', 35, 'For JOB', ''),
(127, 'write less, Do more', '', '', '', '', '', '', '', '', '', '', 35, 'New C-v', ''),
(128, 'using adobe', '', '', '', '', '', '', '', '', '', '', 35, 'For JOB', ''),
(129, 'TEST CV', '00091-67543', 'phase 2 peshawar cantt', 'dasfsadfasdfsafd', 'asdfasdfasdfasdf', '10%', 'F.sc:73.22%', 'Bacholars:67%', 'asdfasdffadsdffdsdasf', 'asdfasdfasdfsdafasdffdfsafddaf', 'gamming', 35, 'My ABDU CV', '');

-- --------------------------------------------------------

--
-- Table structure for table `experience`
--

CREATE TABLE `experience` (
  `id` int(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cv_id` int(11) NOT NULL,
  `companyname` varchar(500) NOT NULL,
  `position` varchar(500) NOT NULL,
  `post_detail` varchar(1000) NOT NULL,
  `timeperiod` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `experience`
--

INSERT INTO `experience` (`id`, `user_id`, `cv_id`, `companyname`, `position`, `post_detail`, `timeperiod`) VALUES
(37, 35, 93, 'NFU', 'CEO', 'grade 17', '13/2/16 to 11/6/16'),
(38, 35, 93, 'CDFE', 'M.D', 'grade 33', '31/2/94 to 27/7/07'),
(39, 35, 93, 'fit', 'GM', 'grade 14', '31/2/02 to 20/5/10'),
(40, 35, 124, 'Test-A', 'ServiceTest-11', 'grade TEN', '13/2/16 to 11/6/16'),
(41, 35, 129, 'NFU', 'CEO', 'grade 17', '31/2/94 to 27/7/07'),
(42, 35, 129, 'fit', 'director', 'grade 17', 'erof sinn hu '),
(43, 35, 129, 'Tetra Pack', 'GM', 'Grade 20', '31/2/02 to 20/5/10');

-- --------------------------------------------------------

--
-- Table structure for table `porfolio`
--

CREATE TABLE `porfolio` (
  `id` int(20) NOT NULL,
  `user_id` int(20) NOT NULL,
  `cv_id` int(20) NOT NULL,
  `port_title` varchar(500) NOT NULL,
  `port_img` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `porfolio`
--

INSERT INTO `porfolio` (`id`, `user_id`, `cv_id`, `port_title`, `port_img`) VALUES
(52, 35, 93, '', '../uploadPicture/'),
(53, 35, 93, '', '../uploadPicture/'),
(54, 35, 93, '', '../uploadPicture/'),
(55, 35, 124, 'portfolio-No : 23c', '../uploadPicture/old_buick.jpg'),
(56, 35, 124, 'portfolio-No : 23YYY', '../uploadPicture/Capture.PNG'),
(57, 35, 124, 'portfolio-No : 1dd', '../uploadPicture/k.PNG'),
(58, 35, 129, 'portfolio-No : 23', '../uploadPicture/14681743_1426262044069760_841697980235600556_n.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(25) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(20) NOT NULL,
  `user_type` varchar(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `user_type`) VALUES
(35, 'ayan', 'akbar', 'ayan@.com', 'qwerty', ''),
(36, 'chloe', 'keen', 'keen@123.com', '123', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cv`
--
ALTER TABLE `cv`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `experience`
--
ALTER TABLE `experience`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `cv_id` (`cv_id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `porfolio`
--
ALTER TABLE `porfolio`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `cv_id` (`cv_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cv`
--
ALTER TABLE `cv`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;
--
-- AUTO_INCREMENT for table `experience`
--
ALTER TABLE `experience`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `porfolio`
--
ALTER TABLE `porfolio`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `cv`
--
ALTER TABLE `cv`
  ADD CONSTRAINT `cv_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `experience`
--
ALTER TABLE `experience`
  ADD CONSTRAINT `experience_ibfk_1` FOREIGN KEY (`cv_id`) REFERENCES `cv` (`id`);

--
-- Constraints for table `porfolio`
--
ALTER TABLE `porfolio`
  ADD CONSTRAINT `porfolio_ibfk_1` FOREIGN KEY (`cv_id`) REFERENCES `cv` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
