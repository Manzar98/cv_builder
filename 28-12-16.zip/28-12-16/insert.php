<?php

//////////////////Sign Up Insertion/////////////////////////

include 'commonfile.php';
include 'header.php';

$first = $_POST['First_name'];
$last=$_POST['Last_name'];
$email=$_POST['Email'];
$password =$_POST['Password'];

$query = '  INSERT INTO users(First_name,Last_name,Email,password)VALUES("'.$first.'","'.$last.'","'.$email.'","'.$password.'")';

$result = mysql_query($query)or die(mysql_error());
//print_r($result);
echo "Your account has been created ";
 ?>
<div class="form-group">
										<div class="row">
											<div class="col-sm-6 col-sm-offset-3">
												 <button><a href="index.php" class="form-control btn btn-login">Back to login</a></button>
											</div>
										</div>
									</div>


 <?php
include 'footer.php';
 ?>