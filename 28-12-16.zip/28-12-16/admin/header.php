<!DOCTYPE html>
<html>
<head>
	<title>Design Layout</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
<nav>
	<ul>
		<li><a href="#">Home</a></li>
		<li><a href="user-manager.php">Manage Users</a></li>
		<li><a href="#">Log out</a></li>
	</ul>
</nav>
