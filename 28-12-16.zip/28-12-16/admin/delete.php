<?php
include '../commonfile.php';

$myid=$_GET['id'];

$slctquery= 'DELETE from users WHERE id='.$_GET['id'];

$slctsql=mysql_query($slctquery) or die(mysql_error());


header('Location: user-manager.php');



?>