<?php
include '../commonfile.php';
include 'header.php';
$query='SELECT * FROM users';
$result=mysql_query($query) or die(mysql_error());

//$resumeResult=mysql_fetch_assoc($result) ;
//echo count($resumeResult);

?>

<table border="1" cellpadding="0" cellspacing="0" width="500">
<?php
while ($resumeResult=mysql_fetch_assoc($result)) {
       
    //echo $resumeResult['id']." | ".$resumeResult['email']."<br/>";





if ($resumeResult['user_type']!='admin') {?>
	
	<tr>
	<td><?php echo $resumeResult['id'];?></td>
	<td><?php echo $resumeResult['first_name'];?></td>
	<td><?php echo $resumeResult['last_name'];?></td>
	<td><?php echo $resumeResult['email'];?></td>
	<td><?php echo $resumeResult['password'];?></td>
<td>
		<a href="delete.php?id=<?php echo $resumeResult['id']; ?>">Delete</a>
	</td> 

</tr>
<?php
}


}





?>
</table>
