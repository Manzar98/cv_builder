<div>&copy; all right reserved.</div>

</body>
</html>