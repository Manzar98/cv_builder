<?php 
$conection=mysql_connect('localhost','root','');//always three strings 1-localhost. 2-user. 3-pasword
if($conection){
//echo "connnection  establish";
}else{
  die('could not connect :'.mysql_error());
}
mysql_select_db('resume');
 
 session_start();


 $query='SELECT  `cv`.*,`users`.*
 FROM `cv`
 LEFT JOIN `users` ON `cv`.`user_id`=`users`.`id`
 WHERE cv.user_id='.$_GET['id'].' AND cv.id='.$_GET['cv_id'].'';

 $sqlQuery=mysql_query($query) or die(mysql_error());

 if(mysql_num_rows($sqlQuery)>0){

 $result=mysql_fetch_assoc($sqlQuery);
 }

?>




<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Gentleman | Personal vCard Template</title>
    <!-- Favicon -->
    <link rel="shortcut icon" href="images/favicon.png">
    <!-- ===== STYLESHEETS ===== -->
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Magnific Popup -->
    <link href="css/magnific-popup.min.css" rel="stylesheet">
    <!-- Owl Carousel -->
    <link href="css/owl.carousel.min.css" rel="stylesheet">
    <link href="css/owl.theme.min.css" rel="stylesheet">
    <!-- Preloader -->
    <link href="css/preloader.min.css" rel="stylesheet">
    <!-- Main styles -->
    <link href="css/theme.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- Responsive styles -->
    <link href="css/responsive.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link href="fontAwsome/font-awesome.min.css" rel="stylesheet">
    <!-- Google Font -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600' rel='stylesheet' type='text/css'>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
   <!--  <script type="text/javascript" src="js/jspdf.min.js"></script>
             <script type="text/javascript" src="js/html2canvas.js"></script>
             <script type="text/javascript">
              function genPDF() {
                // body...
                html2canvas(document.getElementById('home'),{
                  onrendered: function (canvas) {
                   //var img = new Image();
              //img.setAttribute('crossOrigin', 'anonymous');
              // var img = canvas.toDataURL("image/png", 1.0);
               document.body.appendChild(canvas);
              // var doc= new jsPDF("1", "mm", "a4");
              // doc.addImage(img,'JPEG', 10, 10, 180, 280);
              // doc.save('test.pdf');

            //  img.src = url;
                    
                    //var doc = new jsPDF();
                    //doc.addImage(img,'JPEG',20,20);
                  }
                });
              }





             </script>
 -->
  </head>
  <body>
    <!-- Preloader -->
    <div id="loader-wrapper">
      <div class="loader">
        <div class="bounce1"></div>
        <div class="bounce2"></div>
        <div class="bounce3"></div>
      </div>
    </div>
    <!-- end Preloader -->

   

    <!-- Home -->

    <section id="home" class="fill">
      <div class="home-background parallax-section">
        <div class="container-fluid">
          <div class="row">
            <div class="home-box col-xs-12">
              <div>
                <?php echo "<img src=../".$result['uploadfile']." />"?>
                <h1><?php echo  $result['first_name']. $result['last_name'];  ?></h1>
                <p><?php echo $result['description']; ?></p>
              </div>
              <div class="social">
                <ul>
                  <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                  <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                </ul>
              </div>
            </div>
          </div><!-- end row -->
        </div><!-- end container -->
      </div>
    </section>
    <!-- end Home -->

    <!-- Education -->
    <section id="education">
      <div class="container-fluid">
        <div class="row">
          <div class="section-background col-xs-12 col-sm-6" data-mh="match-edu">
            <h2>Education</h2>
            <ul class="resume-box">
              <?php $eduQuery='SELECT * FROM education
            Where education.user_id='.$_GET['id'].' AND education.cv_id='.$_GET['cv_id'].'';
              $edusqlQuery=mysql_query($eduQuery) or die(mysql_error());
              $i=0;
              while($crntResult=mysql_fetch_assoc($edusqlQuery)){ 
                // print_r($crntResult); 
                $valu[$i] = $crntResult['percentage'];
                
                ?>
                
              <li>
                <div class="year" data-mh="match-edu-box-1">
                  <div>
                    <h4><?php echo $crntResult['edu_passingyear']; ?></h4>
                    <span><?php echo $crntResult['edu_title']; ?></span>
                  </div>
                </div>
                <div class="box-content" data-mh="match-edu-box-1">
                  <h4><?php echo $crntResult['edu_name']; ?></h4>
                  
                </div>
              </li>
              <?php $i++; } ?>
            </ul>
          </div>
          <!-- Skills -->
          <div class="skills-background col-xs-12 col-sm-6" data-mh="match-edu">
            <div class="black-layer">
              <div class="middle-content manzar">
                <!-- <?php print_r($valu); ?> -->
                <!-- Skill 1 -->
                <div class="skill-bar">
                  <input type="text" value="0" data-number="<?php echo $valu[0]; ?>" class="dial">
                  <h4>Matric</h4>
                </div>
                <!-- Skill 2 -->
                <div class="skill-bar">
                  <input type="text" value="0" data-number="<?php echo $valu[1]; ?>" class="dial">
                  <h4>Intermediate</h4>
                </div>
                <!-- Skill 3 -->
                <div class="skill-bar">
                  <input type="text" value="0" data-number="<?php echo $valu[2]; ?>" class="dial">
                  <h4>Bacholers</h4>
                </div>
                <!-- end Skill 3 -->
              </div>
            </div>
          </div><!-- end Skills -->
        </div><!-- end row -->
      </div><!-- end container -->
    </section>
    <!-- end Education -->

    <!-- Experience -->
    <section id="experience">
      <div class="container-fluid">
        <div class="row">
          <div class="section-background col-xs-12 col-sm-6 col-sm-push-6" data-mh="match-experience">
            <h2>Experience</h2>
            <ul class="resume-box">
             <?php $expQuery='SELECT * FROM experience Where experience.user_id='.$_GET['id'].' AND experience.cv_id='.$_GET['cv_id'].'';
            $expsqlQuery=mysql_query($expQuery)or die(mysql_error()); 

             while ($crntresult=mysql_fetch_assoc($expsqlQuery)){?> 
            <li>
                <div class="year" data-mh="match-edu-box-1">
                  <div>
                    <h4><?php echo $crntresult['timeperiod']; ?></h4>
                    <span><?php echo $crntresult['companyname']; ?></span>
                  </div>
                </div>
                <div class="box-content" data-mh="match-edu-box-1">
                  <h4><?php echo $crntresult['position']; ?></h4>
                  <p><?php echo $crntresult['post_detail']; ?></p>
                </div>
              </li>
              
                <?php } ?>
            </ul>
          </div>
          <!-- About us -->
          <div class="facts-background col-xs-12 col-sm-6 col-sm-pull-6" data-mh="match-experience">
            <div class="white-layer">
            
              <div class="middle-content">
                <h3>About Us</h3>
                <div class="fact-box">
                <h4><?php echo $result['moredetail'];  ?></h4>
                </div>
              </div>
            </div>
          </div>
          <!-- end  About us -->
        </div><!-- end row -->
      </div><!-- end container -->
    </section>
    <!-- end Experience -->

    <!-- Portfolio -->
    <section id="portfolio">
      <div class="container-fluid">
        <div class="row">
          <div class="section-background col-xs-12 col-sm-6" data-mh="match-portfolio">
            <h2>Portfolio</h2>
            <p><?php echo $result['description'];  ?></p>
          </div>
          <div class="portfolio-content col-xs-12 col-sm-6" data-mh="match-portfolio">
            <div id="portfolioSlider" class="owl-carousel">
           
            <?php  $portQuery='SELECT * FROM porfolio Where porfolio.user_id='.$_GET['id'].' AND porfolio.cv_id='.$_GET['cv_id'].'';
                $portsqlQuery=mysql_query($portQuery) or die(mysql_error()); 
                $i=1;
                 while ($crntresulT=mysql_fetch_assoc($portsqlQuery)) {
                  ?>
              <!-- 1 -->
              <div>
                <?php echo "<img src=../".$crntresulT['port_img']." >";?><!-- image url -->
                <div class="image-layer">
                  <div class="image-title">
                    <h3><?php echo $crntresulT['port_title'];?></h3>
                    <a class="lightbox-popup" href="#popup-<?php echo $i; ?>">view detail</a>
                  </div>
                </div>
                <!-- popup content -->
                <div id="popup-<?php echo $i; ?>" class="mfp-hide popup-box">
                  <?php echo "<img src=../".$crntresulT['port_img']." >";?><!-- image url -->
                  <div class="popup-content">
                  <p><?php echo $crntresulT['port_title'];?></p>
                  </div>
                </div>
                <!-- end popup content -->
              </div>
             <?php $i++;} ?>
            </div>

          </div>
        </div><!-- end row -->
      </div><!-- end container -->
    </section>
    <!-- end Portfolio -->

    <!-- Services -->
    <section id="services">
      <div class="container-fluid">
        <div class="row">
          <div class="section-background col-xs-12 col-sm-6 col-sm-push-6" data-mh="match-services">
            <h2>Services</h2>
            <!-- Service box 1 -->
            <?php $tech=$result['techskill'];  
           
            
            $skill= explode(",",$tech);
            

            $res=count($skill);
            // echo $res;
              
              for ($i=0; $i <$res; $i++) {  ?>
            <div class="service-box">
              <div>
                <i class="fa fa-laptop"></i>
              </div>
              <div>
              
                <h4><?php echo $skill[$i]; ?></h4>
                
              </div>
            </div>
            <?php } 

             $non=$result['progskill'];
               $SKILL= explode(",", $non);
               $prog=count($SKILL);
               for ($i=0; $i <$prog ; $i++) { ?>


                 <div class="service-box">
              <div>
                <i class="fa fa-laptop"></i>
              </div>
              <div>
              
                <h4><?php echo $SKILL[$i]; ?></h4>
                
              </div>
            </div>
              <?php }  ?>
           
            <!-- end Service box 6 -->
          </div>
          <!-- Qout -->
          <div class="facts-background  col-xs-12 col-sm-6 col-sm-pull-6" data-mh="match-services">
            <div class="black-layer">
           
              <div class="middle-content">
                <!-- Fact box 1 -->
               <h3>Qout</h3>
                <div class="fact-box">
                   
                  <h4><?php echo $result['anyquot'] ;?></h4>
                </div>
                
              </div>
            </div>
          </div><!-- end Qout -->
        </div><!-- end row -->
      </div><!-- end container -->
    </section>
    <!-- end Services -->

 <!-- Contact -->
    <section id="contact">
      <div class="container-fluid">
        <div class="row">
          <div class="section-background col-xs-12 col-sm-12 " data-mh="match-contact">
            <h2 class="text-center">Get In Touch</h2>
            <ul class="info text-center">
            <li class="col-sm-1"></li>
              <li class="col-sm-3">
                <i class="fa fa-map-marker"></i>
                <span><?php echo $result['address'];?></span>
              </li>
              <li class="col-sm-3">
                <i class="fa fa-envelope"></i>
                <span><?php echo $result['email']; ?></span>
              </li>
              <li class="col-sm-3">
                <i class="fa fa-phone"></i>
                <span><?php echo $result['cell_no'] ;?></span>
              </li>
            </ul>
          </div>
          
        </div><!-- end row -->
      </div><!-- end container -->
    </section>
    <!-- end Contact -->



    <!-- Footer -->
    <footer>
      <div class="footer-background">
        <div class="container-fluid">
          <div class="row">
            <div class="col-left col-xs-6">
              <p>Made with <i class="fa fa-heart"></i> by <a href="#">Manzar</a></p>
            </div>
            <div class="col-right col-xs-6">
              <a href="#">
                <i class="fa fa-facebook"></i>
              </a>
              <a href="#">
                <i class="fa fa-twitter"></i>
              </a>
              <a href="#">
                <i class="fa fa-linkedin"></i>
              </a>
            </div>
          </div><!-- end row -->
        </div><!-- end container -->
      </div>
    </footer>
   
    <!-- <a href="javascript: genPDF()">Download Image</a> -->
    <!-- end Footer -->

    <!-- ===== JAVASCRIPTS ===== -->
    <!-- jQuery Library -->
    <script src="js/jquery.min.js"></script>
    <!-- Google Maps Library -->
    <script src="https://maps.googleapis.com/maps/api/js?sensor=true"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Magnific Popup -->
    <script src="js/jquery.magnific-popup.min.js"></script>
    <!-- Retina Graphics -->
    <script src="js/retina.min.js"></script>
    <!-- Smooth Scroll -->
    <script src="js/smoothscroll.min.js"></script>
    <!-- Theme Plugins -->
    <script src="js/theme-plugins.min.js"></script>
    <!-- Custom Scripts -->
    <script src="js/scripts.min.js"></script>
  </body>
</html>