<?php 
$conection=mysql_connect('localhost','root','');//always three strings 1-localhost. 2-user. 3-pasword
if($conection){
//echo "connnection  establish";
}else{
  die('could not connect :'.mysql_error());
}
mysql_select_db('resume');
 
 session_start();


 $query='SELECT  `cv`.*,`users`.*
 FROM `cv`
 LEFT JOIN `users` ON `cv`.`user_id`=`users`.`id`
 WHERE cv.user_id='.$_GET['id'].' AND cv.id='.$_GET['cv_id'].'';

 $sqlQuery=mysql_query($query) or die(mysql_error());

 if(mysql_num_rows($sqlQuery)>0){

 $result=mysql_fetch_assoc($sqlQuery);
 }

?>





<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title><?php echo  $result['first_name'];?> | Resume</title>
		<meta name="description" content="John Doe's Resume">
		<meta name="keywords" content="John, Doe, Resume">
		<link rel="stylesheet" type="text/css" href="style.css">
		<link rel="shortcut icon" type="image/x-icon" href="img/icon.png">


             <script type="text/javascript" src="js/jspdf.min.js"></script>
             <script type="text/javascript" src="js/html2canvas.js"></script>
             <script type="text/javascript">
             	function genPDF() {
             		// body...
             		html2canvas(document.getElementById('page'),{
             			onrendered: function (canvas) {
             			 //var img = new Image();
							//img.setAttribute('crossOrigin', 'anonymous');
							var img = canvas.toDataURL("image/png", 1.0);
							 //document.body.appendChild(canvas);
							var doc= new jsPDF("1", "mm", "a4");
							doc.addImage(img,'JPEG', 0, 0, 200, 300);
							doc.save('test.pdf');

						//	img.src = url;
             				
             				//var doc = new jsPDF();
             				//doc.addImage(img,'JPEG',20,20);
             			}
             		});
             	}





             </script>

	</head>
	<body>
	<a href="javascript: genPDF()">Download Image</a>
		<div id="page">
			<div id="header">
				<div id="headerLeft">
					<h1><?php echo  $result['first_name']. $result['last_name'];  ?></h1>
					<p id="caption"><?php echo $result['description']; ?></p>
				</div>
				<div class="photo">
				 <?php echo "<img  src=../".$result['uploadfile']."   />"?>
				 </div>
				<p id="headerRight">
				
				
					<strong>Phone: </strong><?php echo $result['cell_no'] ;?><br>
					<strong>E-mail: </strong><?php echo $result['email']; ?></a><br>
					<!-- <strong>Website: </strong><a href="http://www.example.com/" target="_blank">www.example.com</a><br> -->
					<span><strong>Address: </strong><?php echo $result['address'];?></span><br>
					<!-- <strong>Current address: </strong>13 London St. London -->
				</p>
			</div>
			<!-- <div class="section "> 
				<div class="sectionLeft">
					<h2>Personal<br>information</h2>
				</div>
				<div class="sectionRight">
					<div class="entry">
						<p>
							<strong>Full name: </strong>Jonathan Michael Doe<br>
							<strong>Nationality: </strong>British<br>
							<strong>Date of birth: </strong>4 June 1984<br>
							<strong>First language: </strong>English
						</p>
					</div>
				</div>
			</div>-->
			<div class="section">
				<div class="sectionLeft">
					<h2>Education</h2>
				</div>

				<div class="sectionRight">
				<?php $eduQuery='SELECT * FROM education
            Where education.user_id='.$_GET['id'].' AND education.cv_id='.$_GET['cv_id'].'';
              $edusqlQuery=mysql_query($eduQuery) or die(mysql_error());
              $i=0;
              while($crntResult=mysql_fetch_assoc($edusqlQuery)){ 
                // print_r($crntResult); 
                // $valu[$i] = $crntResult['percentage'];
                
                ?>
					<div class="entry">
						<h5><?php echo $crntResult['edu_passingyear']; ?></h5>
						<h3><?php echo $crntResult['edu_title']; ?></h3>
						<h4><?php echo $crntResult['edu_name']; ?></h4>
					</div>
					 <?php  } ?>
				</div>
			</div>
			<div class="section">
				<div class="sectionLeft">
					<h2>Experience</h2>
				</div>
				<div class="sectionRight">
				<?php $expQuery='SELECT * FROM experience Where experience.user_id='.$_GET['id'].' AND experience.cv_id='.$_GET['cv_id'].'';
            $expsqlQuery=mysql_query($expQuery)or die(mysql_error()); 

             while ($crntresult=mysql_fetch_assoc($expsqlQuery)){?> 
					<div class="entry">
						<h5><?php echo $crntresult['timeperiod']; ?></h5>
						<h3><?php echo $crntresult['companyname']; ?></h3>
						<h4><?php echo $crntresult['position']; ?></h4>
						<p class="details">
							<?php echo $crntresult['post_detail']; ?>
						</p>
					</div>
					<?php } ?>
				</div>
			</div>
			<div class="section">
				<div class="sectionLeft">
					<h2>Skills</h2>
				</div>
				<div class="sectionRight skill">
					 <?php $tech=$result['techskill'];  
           
            
            $skill= explode(",",$tech);
            

            $res=count($skill);
            // echo $res;
              
              for ($i=0; $i <$res; $i++) {  ?>
            <div class="service-box techskill">
              
             
              
                <h4><?php echo $skill[$i]; ?></h4>
                
             
            </div>
            <?php } 

             $non=$result['progskill'];
               $SKILL= explode(",", $non);
               $prog=count($SKILL);
               for ($i=0; $i <$prog ; $i++) { ?>


                 <div class="service-box progskill">
              
              
              
                <h4><?php echo $SKILL[$i]; ?></h4>
                
              
            </div>
              <?php }  ?>
				</div>
			</div>
			
			<div class="section">
				<div class="sectionLeft">
					<h2>About me</h2>
				</div>
				<div class="sectionRight">
					<div class="entry">
						<p><?php echo $result['moredetail'];  ?>
						</p>
					</div>
				</div>
			</div>
			<div class="section">
				<div class="sectionLeft">
					<h2>Contact</h2>
				</div>
				<div class="sectionRight">
					<div class="entry">
						<p>
							<strong>Phone: </strong><?php echo $result['cell_no'] ;?><br>
							<strong>E-mail: </strong><?php echo $result['email']; ?><br>
							<strong>Address: </strong><?php echo $result['address'];?><br>
						</p>
					</div>
				</div>
			</div>
		</div>
		
	</body>
</html>
 