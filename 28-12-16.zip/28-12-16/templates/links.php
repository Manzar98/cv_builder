
   <!-- Bootstrap -->
    <link href="gentleman/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
      
      .white-layer h4 {
    color: slategrey;
}
.card_img{
  min-width: 200px;
  min-height: 260px;
}
    </style>
<br><br><br>
<div class="container text-center  ">
<div class="col-sm-3 col-md-2"></div>
<div class="row">
  <div class="col-sm-6 col-md-4">
    <div class="thumbnail card_img">
      <a href="/learning/php/28-12-16/templates/gentleman/index.php?cv_id=<?php echo $_GET['cv_id'];?>&id=<?php echo $_GET['id'];?>" ><img src="images/gentleman1.png" class="card_img"></a>
      <div class="caption pull-left">
        <h3>Thumbnail label</h3>
        <p>...</p>
        
      </div>
    </div>
  </div>


  <div class="col-sm-6 col-md-4">
    <div class="thumbnail ">
      <a href="/learning/php/28-12-16/templates/HTML_Resume_Template/index.php?cv_id=<?php echo $_GET['cv_id'];?>&id=<?php echo $_GET['id'];?>"><img src="/learning/php/28-12-16/templates/HTML_Resume_Template/img/1.png" class="card_img"></a>
      <div class="caption pull-left">
        <h3>Thumbnail label</h3>
        <p>...</p>
       
      </div>
    </div>
  </div>
</div>



</div>



