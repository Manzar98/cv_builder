<?php
use Dompdf\Adapter\CPDF;
use Dompdf\Dompdf;
use Dompdf\Exception;
require_once 'dompdf-master/autoload.inc.php';

//spl_autoload_register('DOMPDF_autoload');

function pdf_create($hTML, $filename, $paper, $orientation, $stream=TRUE){
	$dompdf= new DOMPDF();
	$dompdf->set_paper($paper, $orientation);
	$dompdf->load_html($hTML);
	$dompdf->render();
	$dompdf->stream($filename.".pdf");
}
$filename='file_name';
$dompdf= new DOMPDF();
$hTML=file_get_contents('file_html.html');
pdf_create($hTML, $filename, 'A4', 'portrait')
?>


