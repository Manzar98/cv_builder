<?php


$conection=mysql_connect('localhost','root','');//always three strings 1-localhost. 2-user. 3-pasword
if($conection){
//echo "connnection  establish";
}else{
  die('could not connect :'.mysql_error());
}
mysql_select_db('resume');
 
 session_start();


 $query='SELECT  `cv`.*,`users`.*
 FROM `cv`
 LEFT JOIN `users` ON `cv`.`user_id`=`users`.`id`
 WHERE cv.user_id='.$_GET['id'].' AND cv.id='.$_GET['cv_id'].'';

 $sqlQuery=mysql_query($query) or die(mysql_error());

 if(mysql_num_rows($sqlQuery)>0){

 $result=mysql_fetch_assoc($sqlQuery);
 }


?>

<!DOCTYPE html>

<html dir="ltr" lang="en-US">
<head>
	
	<!-- meta tags -->
	<meta charset="UTF-8">
	<!-- <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> -->

	<meta content="LoveCV - Photography Onepage Resume" name="description">
	<meta content="http://themeforest.net/user/artweb/portfolio" name="author">
	<meta content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0" name="viewport">
	
	<link rel="apple-touch-icon" sizes="57x57" href="images/fav/apple-touch-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="images/fav/apple-touch-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="images/fav/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="images/fav/apple-touch-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="images/fav/apple-touch-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="images/fav/apple-touch-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="images/fav/apple-touch-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="images/fav/apple-touch-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="images/fav/apple-touch-icon-180x180.png">
	<link rel="icon" type="image/png" href="images/fav/favicon-32x32.png" sizes="32x32">
	<link rel="icon" type="image/png" href="images/fav/favicon-194x194.png" sizes="194x194">
	<link rel="icon" type="image/png" href="images/fav/favicon-96x96.png" sizes="96x96">
	<link rel="icon" type="image/png" href="images/fav/android-chrome-192x192.png" sizes="192x192">
	<link rel="icon" type="image/png" href="images/fav/favicon-16x16.png" sizes="16x16">
	<link rel="manifest" href="images/fav/manifest.json">
	<link rel="shortcut icon" href="images/fav/favicon.ico">
	<meta name="msapplication-TileColor" content="#de4b33">
	<meta name="msapplication-TileImage" content="images/fav/mstile-144x144.png">
	<meta name="msapplication-config" content="images/fav/browserconfig.xml">
	<meta name="theme-color" content="#ffffff">
	
	<!-- page title -->
	<title>Manzar  - Creative Developer</title>

	<!-- css stylesheets -->
	<link rel="stylesheet" href="css/ie.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/print.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/screen.css" media="screen, projection" id="jssDefault" type="text/css" />

	<!-- JS files -->
	<script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
	<script type="text/javascript" src="js/headroom.min.js"></script>

</head>
<body id="homepage">
	<div class="site-wrapper">

		<!-- Header -->
	  	<header id="header" role="banner">
	  	
			<div class="top-bg" style="background-image: url(../<?php echo $result['uploadfile'] ?>);  
                    position: relative;
                    height: 675px; ">
               
				<div class="overlay"></div>
				<div class="container">
				<div class="sideLogo top-logo">
					<h2><?php echo  $result['first_name']. " ".$result['last_name'];  ?></h2>
				</div>
					
					<div class="scrolldown">
						<span class="icon-mouse"></span>
						<span class="fa fa-angle-down"></span>
					</div>
				</div>
			</div>
			<nav class="nav-main headroom">
				<div class="container">
					<div class="logo">
						<a href="#header">
							<span class="normal"><?php echo  $result['first_name']. $result['last_name'];  ?></span>
							<span class="small">ML</span>
						</a>
					</div>
					<div class="menu-button"></div>
					<div class="main-menu">
						<ul class="flexnav" data-breakpoint="768">
							<li><a href="#about">About</a></li>
							<li><a href="#education">Education</a></li>
							<li><a href="#skills">Skills</a></li>
							<li><a href="#expirience">Experience</a></li>
							<li><a href="#portfolio">Portfolio</a></li>
							<li><a href="#contact">Contact</a></li>
						</ul>
					</div>
				</div>
			</nav>
		</header>
		<!-- Header End -->

		<!-- Main -->
		<div class="main" role="main">
			<section id="about">
				<div class="container">
					<h2 class="section-title">
						About me
					</h2>
					<div class="content">
						<div class="about-me">
							<div class="me">
								<?php echo "<img src=../".$result['uploadfile']." />"?>
								<div class="overlay"></div>
							</div>
							<div class="short-resume">
								<h4>Short Resume</h4>
								<ul>
									<li>Name:  <?php echo  $result['first_name']. $result['last_name'];  ?></li>
									<!-- <li>Date of birth: 19 July 1985</li> -->
									<li>Address:  <?php echo $result['address'];?> </li>
									<li>Phone:    <?php echo $result['cell_no'];?> </li>
									<li>E-mail:   <?php echo $result['email'];?> </li>
								</ul>
							</div>
							<div class="short-profile">
								<h4>Profesional Profile</h4>
								<p><?php echo $result['moredetail'];  ?></p>
							</div>
							<div class="socials">
								<ul>
									<li><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#" target="_blank"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#" target="_blank"><i class="fa fa-linkedin"></i></a></li>
									<li><a href="#" target="_blank"><i class="fa fa-google-plus"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</section>
			<section id="education">
				<div class="container">
					<h2 class="section-title">Education</h2>

					 <?php $eduQuery='SELECT * FROM education
            Where education.user_id='.$_GET['id'].' AND education.cv_id='.$_GET['cv_id'].'';
              $edusqlQuery=mysql_query($eduQuery) or die(mysql_error());
              $i=0;
              while($crntResult=mysql_fetch_assoc($edusqlQuery)){ ?>
					<div class="content">
						<div class="wrapper-block">
							<?php if($i%2==1){ ?>
							<div class="edu-block right">
							<?php }else{?>
							<div class="edu-block left">
							<?php } ?>
								<span class="edu-date"><?php echo $crntResult['edu_passingyear']; ?></span>
								<h4><?php echo $crntResult['edu_name']; ?></h4>
								<h5><?php echo $crntResult['edu_title']; ?></h5>
								<p>Aenean magna leo, mollis at dui eu, convallis molestie turpis. Morbi ante nisl, ultricies vitae mattis vestibulum, sagittis a libero. Integer tempor nec erat.</p>
							</div>
							<span class="block-ico"><i class="fa fa-bank"></i></span>
						</div>
						<?php  $i++; 
						} ?>
					</div>
				</div>
			</section>
			<section id="skills">
				<div class="container">
					<h2 class="section-title">Skills</h2>
					<div class="content">
						<div class="hobbies">
							<div class="title-wrapper">
								<h3>Technical</h3>
							</div>
							<div class="width-box1">
                              <div class="col-2">
								<ul>
								<?php  $non=$result['progskill'];
                                $SKILL= explode(",", $non);
                                $prog=count($SKILL);
                                for ($i=0; $i <$prog ; $i++) { ?>
									<li><span class="hobbie-icon"><i class="fa fa-laptop"></i></span><span class="hobbie-name"><?php echo $SKILL[$i]; ?></span></li>
									 <?php } ?>
								</ul>
							</div>
							</div>
						</div>
						<div class="hobbies">
							<div class="title-wrapper">
								<h3>Non-Technical</h3>
							</div>
							<div class="width-box1">
							<div class="col-1">
								<ul>
								    <?php $tech=$result['techskill'];  
           
                                    $skill= explode(",",$tech);
           
                                    $res=count($skill);
                                    // echo $res;
                                    
                                    for ($i=0; $i <$res; $i++) {  ?>
									<li><span class="hobbie-icon"><i class="fa fa-laptop"></i></span><span class="hobbie-name"><?php echo $skill[$i]; ?></span></li>
									   <?php } ?>
									
								</ul>
							</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<section id="expirience">
				<div class="container">
					<h2 class="section-title">Expirience</h2>
					<?php $expQuery='SELECT * FROM experience Where experience.user_id='.$_GET['id'].' AND experience.cv_id='.$_GET['cv_id'].'';
            $expsqlQuery=mysql_query($expQuery)or die(mysql_error()); 
                $i=0;
             while ($crntresult=mysql_fetch_assoc($expsqlQuery)){?> 
                  
					<div class="content">
					
						<div class="wrapper-block">
						<?php if($i%2==1){ ?>
							<div class="edu-block right">
							<?php }else{?>
							<div class="edu-block left">
							<?php } ?>
							
								<span class="edu-date"><?php echo $crntresult['timeperiod']; ?></span>
								<h4><?php echo $crntresult['companyname']; ?></h4>
								<h5><?php echo $crntresult['position']; ?></h5>
								<p><?php echo $crntresult['post_detail']; ?></p>
							</div>
							<span class="block-ico"><i class="fa fa-camera-retro"></i></span>
						</div>
						   
					</div>
					<?php  $i++; } ?>
				</div>
			</section>
			<section id="portfolio">
				<div class="container">
					<h2 class="section-title">Portfolio</h2>
					<div class="content">

						
						<div class="filter-options"> 
							<a href="#" class="active" data-group="all">All</a>
							<a href="#" data-group="graphics">Graphic</a>
							<a href="#" data-group="web">Web</a>
							<a href="#" data-group="photo">Photo</a>
						</div>      
                           
                           <?php  $portQuery='SELECT * FROM porfolio Where porfolio.user_id='.$_GET['id'].' AND porfolio.cv_id='.$_GET['cv_id'].'';
                $portsqlQuery=mysql_query($portQuery) or die(mysql_error()); 

                 while ($crntresulT=mysql_fetch_assoc($portsqlQuery)) {?>
						<div id="grid" class="row">
						
							<div class="item narrow" data-groups='["all"]'>
								<a href="#"><?php echo "<img src=../".$crntresulT['port_img']."  >";?></a>
								<h5><?php echo $crntresulT['port_title'];?></h5>
							</div>
						
							<!-- sizer -->
							<div class="narrow shuffle_sizer"></div>     
							
						</div><!-- /#grid -->
						<?php } ?>     
					</div>
				</div>
			</section>
		</div>
		<!-- Main End -->
		
		<!-- Footer -->
		<footer id="contact" class="footer">
			<div class="overlay"></div>
			<h2 class="section-title">
				Contact
			</h2>
			<div class="footer-blocks">
				<div class="container">
					<div class="block-info block">
						<h3 class="block-title">
							Info
						</h3>
					</div>
					<div class="block-content pull-left">
						<ul>
									<li>
										<i class="fa fa-map-marker"></i>
										Address: <br>
										 <?php echo $result['address'];?>
									</li>
									</ul>

					</div>
					<div class="block-contenT pull-left">
						 <ul>
									<li>
										<i class="fa fa-mobile-phone"></i>
										Phone: <br>
										 <?php echo $result['cell_no'];?>
									</li>
									</ul> 

					</div>
					<div class="block-CONTENT pull-left">
						 <ul>
									<li>
										<i class="fa fa-envelope-o"></i>
										E-mail: <br>
										 <?php echo $result['email'];?>
										 
									</li>
									</ul> 

					</div>

				</div>
			</div>
			<div class="footer-copyright">
				<div class="container">
					<div class="copyright">
						Copyright &copy; 2017 Manzar Noman
					</div>
					<!-- <div class="backtop">
						<a href="#header"><i class="fa fa-angle-up"></i></a>
					</div> -->
				</div>
			</div>
		</footer>
		<!-- Footer End -->
	</div>

	<!-- JS files -->
	<script type="text/javascript" src="js/jquery.flexnav.min.js"></script>
	<script type="text/javascript" src="js/jquery.shuffle.modernizr.js"></script>
	<script type="text/javascript" src="js/jquery-scrollspy.js"></script>
	<script type="text/javascript" src="js/shuffle.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
</body>
</html>