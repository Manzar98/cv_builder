<?php      
 ////////////////Main Login/Signup Page/////////////////////

include 'header.php';

 ?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
<link rel="stylesheet" type="text/css" href="css/style.css">
    
    <style type="text/css">
        a{
            
            text-decoration: none;
            padding: 5px;
            color: #000000;
        }
    </style>
</head>
<body>

    <?php if(!isset($_GET['t']) ){ ?>
        <div id="loginSec"> 
             
             <?php include 'login.php'; ?>
        </div>

    <?php }else{ ?>
        <div id="signupSec">
            
             <?php include 'signup.php'; ?>
        </div>
    <?php } ?>

   </body>
    </html>
<?php 
include 'footer.php';
?>



